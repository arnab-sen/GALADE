﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProgrammingParadigms;

namespace DomainAbstractions
{
    /// <summary>
    /// Generates a C# source file from a JSON configuration.
    /// </summary>
    public class SourceFileGenerator
    {

    }
}
